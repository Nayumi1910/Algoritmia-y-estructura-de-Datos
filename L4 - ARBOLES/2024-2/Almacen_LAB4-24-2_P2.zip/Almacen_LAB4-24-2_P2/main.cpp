/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: miria
 *
 * Created on 6 de diciembre de 2024, 18:48
 */

#include <cstdlib>
#include <iostream>
#include <cstring>
#include "ArbolBB.h"
#include "funcionesAB.h"
#include "funcionesABB.h"
#include "Pila.h"
#include "funcionesPila.h"

using namespace std;

/*
 * 
 */
void ingresar_lote(struct ArbolBinarioBusqueda &arbol, int anio, int cantidad);
void insertaVerifica(NodoArbol *& nodo,int  anio, int cantidad);
void ImprimirDescendente(NodoArbol *nodo);
NodoArbol* buscarNodoActual(NodoArbol *arbol, int dato);
NodoArbol* buscarRecursivoNuevo(struct NodoArbol * nodo, int dato);


int main(int argc, char** argv) {
    
    ArbolBinarioBusqueda arbol;
    construir(arbol);
    
    ingresar_lote(arbol, 2018, 100);
    ingresar_lote(arbol, 2011, 300);
    ingresar_lote(arbol, 2010, 175);
    ingresar_lote(arbol, 2017, 25);
    ingresar_lote(arbol, 2022 ,50);
    ingresar_lote(arbol, 2019, 125);
    ingresar_lote(arbol, 2020, 75);
    ingresar_lote(arbol, 2023, 200);
    
    enOrden(arbol);
    cout << endl;
    
    ImprimirDescendente(arbol.arbolBinario.raiz);
    
    
    
    
    

    return 0;
}

void ingresar_lote(struct ArbolBinarioBusqueda &arbol, int anio, int cantidad){
    
    insertaVerifica(arbol.arbolBinario.raiz, anio, cantidad);
    
}

void insertaVerifica(NodoArbol * &nodo,int  anio, int cantidad){
    
    if (esNodoVacio(nodo)){
        plantarArbolBinario(nodo, nullptr, anio, cantidad, nullptr);
    }else{
        
        if (nodo->elemento > anio){
            insertaVerifica(nodo->izquierda, anio, cantidad);
        }else {
            if (nodo->elemento < anio){
                insertaVerifica(nodo->derecha, anio, cantidad);
            }else{
                //cout << "El nodo ya esta en el arbol" << endl;
                nodo->cantidad = nodo->cantidad + cantidad;
            }
        }
        
    }
    
}


void ImprimirDescendente(NodoArbol *nodo){
    
    Pila pila;
    construir(pila);
    NodoArbol *actual=nodo;
    
    int dato;
    
    while( actual!= nullptr or !esPilaVacia(pila)){
        
        if(actual!= nullptr){
            
            dato = actual->elemento;
            apilar(pila,dato);
            actual=actual->derecha;
            
        }else{
            
            dato = desapilar(pila);
            actual = buscarNodoActual(nodo,dato);
            cout<< dato <<" ";
            actual=actual->izquierda;
        }
    }
    cout<<endl;
}


NodoArbol* buscarNodoActual(NodoArbol *arbol, int dato){
    return buscarRecursivoNuevo(arbol, dato);
}

NodoArbol* buscarRecursivoNuevo(struct NodoArbol * nodo, int dato){
    
    if(comparaABB(nodo->elemento, dato) == 0)
        return nodo;
    if(comparaABB(nodo->elemento, dato) == 1)
        return buscarRecursivoNuevo(nodo->izquierda, dato);
    else
        if(comparaABB(nodo->elemento, dato) == -1)
            return buscarRecursivoNuevo(nodo->derecha, dato);
}