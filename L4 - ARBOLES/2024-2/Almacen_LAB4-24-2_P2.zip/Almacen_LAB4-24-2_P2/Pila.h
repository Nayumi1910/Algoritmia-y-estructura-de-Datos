/*
 * File:   Pila.h
 * Author: ANA RONCAL
 * Created on 7 de abril de 2024, 03:40 PM
 */

#ifndef PILA_H
#define PILA_H

#include "Lista.h"
struct Pila{
    struct Lista lista;
};

#endif /* PILA_H */

