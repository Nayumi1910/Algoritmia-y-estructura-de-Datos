/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Karolyn Nayumi Aquiño Torres 20203608
 *
 * Created on 2 de noviembre de 2024, 08:04 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
using namespace std;
void merge(int bitacora[],int inicio,int medio,int fin){
    int p1,p2;
    p1=medio-inicio+1;
    p2=fin-medio;
    int P[p1+1],Q[p2+1];
    for(int i=inicio;i<=medio;i++){
        P[i-inicio]=bitacora[i];
    }
    P[p1]=10000;
    for(int i=medio+1;i<=fin;i++){
        Q[i-medio-1]=bitacora[i];
    }
    Q[p2]=10000;
    int p,q;
    p=q=0;
    for(int i=inicio;i<=fin;i++){
        if(P[p]<Q[q]){
            bitacora[i]=P[p];
            p++;
        }else{
            bitacora[i]=Q[q];
            q++;
        }
    }
}
int encontrarTriple(int bitacora[],int inicio,int fin){
    if(inicio>=fin)return bitacora[inicio];
    int medio=(inicio+fin)/2;
    if(medio%2==0){
        if(bitacora[medio]==bitacora[medio+1]){
            encontrarTriple(bitacora,medio+2,fin);
        }else{
            encontrarTriple(bitacora,inicio,medio);
        }
    }else{
        if(bitacora[medio]==bitacora[medio-1]){
            encontrarTriple(bitacora,medio+1,fin);
        }else{
            encontrarTriple(bitacora,inicio,medio-1);
        }
    }
}
void mergeSort(int bitacora[],int inicio,int fin){
    if(inicio==fin)return ;
    int medio=(inicio+fin)/2;
    mergeSort(bitacora,inicio,medio);
    mergeSort(bitacora,medio+1,fin);
    merge(bitacora,inicio,medio,fin);
}
int main(int argc, char** argv) {
    int bitacora[]={1,6,3,4,5,6,3,7,5,4,3,1,7};
    int n=sizeof(bitacora)/sizeof(bitacora[0]);
    //primero ordeno y seria por mergesort nlog(n)
    mergeSort(bitacora,0,n-1);
    //imprimimos para corroborar
    for(int i=0;i<n;i++){
        cout<<bitacora[i]<<" ";
    }
    cout<<endl;
    //Ahora brocedemos a buscar el que es triple complejidad log(n)
    int salio=encontrarTriple(bitacora,0,n-1);
    cout<<"El empleado: "<<salio<<" ingreso y no volvio a salir"<<endl;
    
    return 0;
}

