/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Karolyn Nayumi Aquiño Torres 20203608
 *
 * Created on 2 de noviembre de 2024, 08:07 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int encontrarMayor(int muestras[],int inicio,int fin){
    if(inicio>=fin){
        return muestras[inicio];
    }
    int medio=(inicio+fin)/2;
    if(muestras[medio]>muestras[medio-1] and muestras[medio]>muestras[medio+1]){
        return muestras[medio];
    }else{
        if(muestras[medio]>muestras[medio-1]){
            encontrarMayor(muestras,medio+1,fin);
        }else{
            encontrarMayor(muestras,inicio,medio);
        }
    }
}
int calcularMinerales(int muestras[],int inicio,int fin,int cont){
    if(inicio>=fin)return cont;
    int medio=(inicio+fin)/2;
    //los numeros mayores a 0, los tomare como 1, usare en contar CEROS
    if(muestras[medio]==0){
        calcularMinerales(muestras,medio+1,fin,medio+1);
    }else{
        calcularMinerales(muestras,inicio,medio,cont);
    }
}
int calcularMinerales2(int muestras[],int inicio,int fin,int cont){
    if(inicio>=fin)return cont;
    int medio=(inicio+fin)/2;
    //los numeros iguales a 0 los tomare como 1, usare en contar CEROS
    if(muestras[medio]>0){
        calcularMinerales2(muestras,medio+1,fin,medio+1);
    }else{
        calcularMinerales2(muestras,inicio,medio,cont);
    }
}
int main(int argc, char** argv) {
    int muestras[][10]={{0,0,0,3,3,7,5,5,1,1},
                        {8,8,10,9,9,5,4,4,2,0},
                        {3,5,8,9,7,6,4,2,0,0},
                        {9,7,7,4,4,4,2,0,0,0},
                        {0,2,2,3,3,4,4,5,3,3},
                        {0,0,0,0,0,0,2,3,4,5},
                        {1,2,2,3,3,4,3,2,0,0},
                        {0,0,0,0,0,0,3,5,5,7},
                        {6,5,5,2,2,1,0,0,0,0},
                        {3,2,2,0,0,0,0,0,0,0}};
    int n=10;
    //PARTE A
    int mayor=0,posMuestra;
//    int tam=10;
    //tamaño d ela muestra
    int tam=sizeof(muestras[0])/sizeof(muestras[0][0]);
    // la complejidad seria n*log(n)
    for(int i=0;i<n;i++){
        //usamos encontrar mayor
        int dato=encontrarMayor(muestras[i],0,tam-1);
//        cout<<dato<<endl;
        //guardamos dato mayor
        if(dato>mayor){
            mayor=dato;
            posMuestra=i+1;
        }
    }
    cout<<"La maxima pureza de las muestras es: "<<mayor<<" (encontrado en "
            "la muestra "<<posMuestra<<")"<<endl;
    //PARTE B
    //usamos
    int minerales[n]={},max=0,cant=0,estrato,estrato2=0;
    for(int i=0;i<n;i++){
        //Usare el cuenta cero
         //como no lo ordenaremos, nos guiaremos del primer elemento
        //en caso de que sea difernete de cero, contaremos los numeros mayores a 0
        if(muestras[i][0]!=0){
            estrato2=calcularMinerales2(muestras[i],0,tam-1,0);
            //guardamos datos
            if(estrato2>=max){
                max=estrato2;
                minerales[cant]=i;
                cant++;
            }
            //en caso de que sea el primer elemento igual a 0 
        }else{
            estrato=calcularMinerales(muestras[i],0,tam-1,0);
            //guardamos datos
            if((tam-estrato)>=max){
                max=(tam-estrato);
                minerales[cant]=i;
                cant++;
            }
        }
    }
    cout<<"Las muestras con mayor cantidad de niveles con minerales son: ";
    //el primero no lo cuento y que es de referencia 
    for(int i=1;i<cant;i++){
        cout<<minerales[i]+1<<" ";
    }
    cout<<"con estratos de: "<<max<<endl;
    return 0;
}

